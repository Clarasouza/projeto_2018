<?php 
include 'cabecalho.php';
$lista=listaResenhas();
foreach ($lista as $dados) {
if () {
	
}
?>
