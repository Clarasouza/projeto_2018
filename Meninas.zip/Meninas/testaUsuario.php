	<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.css"></script>
	<link rel="shortcut icon" href="imagens/logopreto.png" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="semantic/semantic.min.js"></script>
	<script type="text/javascript" src="js/js.js"></script>
	<link rel="stylesheet" type="text/css" href="css/principal.css">
	<title>Read.</title>
	<meta charset="UTF-8">
</head>
<body class="cor_menu3">
<?php
include "funcoes.php";
$user=$_POST['user'];
$senha=$_POST['senha'];
$testa=testaUsuario($user,$senha);
if(isset($_SESSION['nome'])){
	$nome=$_SESSION['nome'];
}
if($testa==0){
	$teste=0;
}elseif($testa==1) {
	$teste=1;
}else{
	$teste=0;
}
if($teste==1){
	echo '
	<div class="fundo3 limite espacocadastro">
		<div class="label formatacaoletra black">Logando</div>
		<div class="ui indicating progress" data-value="4" data-total="5" id="example4">
			<div class="bar">
				<div class="progress"></div>
			</div>
		</div>
	</div>
	<meta http-equiv="refresh" content="1;URL="index.php" />
	';
	echo "<meta http-equiv='refresh' content='3; url=index.php?testa=1'>";
}else{
	echo "<center><h1>Logado</h1></center>";
	echo "<meta http-equiv='refresh' content='2; url=index.php'>";
}