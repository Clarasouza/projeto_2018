<?php
include 'cabecalho.php';
?>
<div class="clear">.</div>
<div class="ui five column centered grid">
	<div class="column">
<img class="ui avatar image medium" src="imagens/aline.jpg">
	</div>
</div>
<section class="lateralUsuario">.</section>
<section class="conteudo">
<div class="ui secondary pointing menu">
<a  class='item'></a>
<a  class='item'></a>
<a  class='item'></a>
  <a class="item" href="favoritos.php">
    Favoritos
  </a>
  <a class="item" href="usuarioInformacoes.php">
    Informações
  </a>
  <a class="item" href="nada.php">
  	Secreto
  </a>
</div>
</section>
<section class="lateralUsuario"></section>