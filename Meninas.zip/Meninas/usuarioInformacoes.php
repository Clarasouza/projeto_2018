<?php
include 'cabecalho.php';
$codigo=$_SESSION['nome'];
$dadosusu=InfoUsuario($codigo);
print_r($codigo);
print_r($dadosusu);
foreach ($dadosusu as $dados) {
	
}
?>
