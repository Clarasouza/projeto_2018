<div class="ui cor_menu vertical footer segment">
    <div class="ui center aligned container">
      <div class="ui stackable inverted divided grid">
        <div class="three wide column">
          <h4 class="ui inverted header">Desenvolvedor</h4>
          <div class="ui inverted link list">
            <a href="#" class="branca">Clara Souza de Jesus</a>
            
          </div>
        </div>
        <div class="three wide column">
          <h4 class="ui inverted header">Desenvolvedor</h4>
          <div class="ui inverted link list">
            <a href="#" class="branca">Felipe Passig  Coscodai</a>
          </div>
        </div>
        <div class="three wide column">
          <h4 class="ui inverted header">Desenvolvedor</h4>
          <div class="ui inverted link list">
            <a href="#" class="branca">Leticia Helen de Sousa</a>
          </div>
        </div>
        <div class="seven wide column">
          <h2 class="ui header">.Read</h2>
          <p class="branca">Faça dos seus sonhos realidade</p>
        </div>
      </div>
      <div class="ui inverted section divider"></div>
      <img src='imagens/aline.jpg' class="ui centered mini image circular">
    </div>
</div>
</body>
</html>