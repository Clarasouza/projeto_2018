<!DOCTYPE html>
<html>
<head>
	<title>Logar</title>
	<meta charset="utf-8">
</head>
<body>
	<form name="loginform" method="post" action="autentica.php">
		<label>email</label>
		<input type="email" placeholder="email" name="email"> <br> <br>
		<input type="password" name="senha" placeholder="senha"> <br> <br>
		<input type="submit" value="entrar">
	</form>


</body>
</html>