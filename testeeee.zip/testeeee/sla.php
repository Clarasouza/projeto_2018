<?php
$foto=$_POST['foto'];
echo "$foto";