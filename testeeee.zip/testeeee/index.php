<!DOCTYPE html>
<html>
<head>
	<title>AAAAAAAAAAA</title>
</head>
<body>
	<a href="login.php">Logar</a>
	<a href="cadastro.php">Cadastrar</a>
	<a href="cadastroResenho">Cadastrar Resenha</a>
	<a href="cadastroresenha.php">resenha</a>
</body>
</html>