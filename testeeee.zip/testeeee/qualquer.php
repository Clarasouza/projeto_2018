<!DOCTYPE html>
<html>
<head>
	<title>aaa</title>
</head>
<body>
	<form method="post" action="sla.php">
		<input type="file" name="foto">
		<input title="Clique para carregar arquivo" type="submit" name="envia">
	</form>
</body>
</html>