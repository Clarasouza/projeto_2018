<?php
$host="localhost";
$user="root";
$pass="";
$banco="cadastro";
echo "$host,$user,$pass,$banco";
$conexao= mysql_connect($host, $user, $pass) or die (mysql_error());
mysql_select_db($banco) or die(mysql_error());
?>
<!DOCTYPE html>
<html>
<head>
	<title>aaaa</title>
</head>
<body>
<script type="text/javascript">
	function loginsucesso(){
		setTimeout("window.location='index.php'",2000);
	}
	function loginfalho(){
		setTimeout("window.location='login.php'",2000);
	}

</script>

<?php
$email=$_POST['email'];
$senha=$_POST['senha'];
$sql=mysql_query("SELECT * FROM cad_usu WHERE email='$email' && senha='$senha'")or die(mysql_error());
$row= mysql_num_rows($sql);
if ($row > 0 ) {
	session_start();
	$_SESSION['email']=$_POST['email'];
	$_SESSION['senha']=$_POST['senha'];
	echo "<center>Você logou</center>";
	echo "<script>loginsucesso()</script>";
}else{
	echo "<center>Nome ou senha errado</center>";
	echo "<script>loginfalho()</script>";
}


?>
</body>
</html>