<!DOCTYPE html>
<html>
<head>
	<title>Logar</title>
	<meta charset="utf-8">
</head>
<body>
	<form name="loginform" method="post" action="resenha.php">
		<label>nome categoria</label>
		<input type="text" placeholder="nome" name="nomecategoria"> <br> <br>
		 <br> <br>
		<input type="submit" value="entrar">
	</form>


</body>
</html>