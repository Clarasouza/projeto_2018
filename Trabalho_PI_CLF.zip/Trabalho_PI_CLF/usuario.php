<?php
include 'cabecalho.php';
?>
<div class="clear">.</div>
<div class="ui five column centered grid">
	<div class="column">
<img class="ui avatar image medium" src="imagens/usua.png">
	</div>
</div>
<div class="nomeUsuario">
<h2 class="black"><?php echo $_SESSION["nome"];?></h2>
<br>
</div>
<section></section>
<section class="lateralUsuario">.</section>
<section class="conteudo">

  <!-- SERVE PAA MESCLAR O MENU ATUAL COM O ANTIGO -->
<div class="ui secondary pointing menu">
  
<!--
  <a class="item menu_usus" href="favoritos.php">
    Favoritos
  </a>
  <a class="item" href="usuarioInformacoes.php">
    Informações
  </a>
  <a class="item" href="resenhausuario.php">
    Minhas Resenhas
  </a>
-->
  <div class="ui three item menu">
    <a class="item" href="favoritos.php" >Favoritados</a>
    <a class="item" href="usuarioInformacoes.php">Informações</a>
    <a class="item" href="minhasResenhas.php">Minhas resenhas</a>
  </div>
</div>
</div>
</section>
<section class="lateralUsuario"></section>