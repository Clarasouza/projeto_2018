<?php
include 'cabecalho.php';
?>

<div class="topper">.</div>
<div class="fundo1 limite2 espacologin">
  <div class="ui column middle aligned very relaxed stackable grid center aligned page grid">
    <div class="column">
 <div class="ui container">
  <div class="header">
  Nova Senha
  </div>
  <div class="content">
        <div class="ui form" >
          <div class="field">
            <label>Senha</label>
            <div class="ui left icon input">
              <input type="password" placeholder="Senha" name="novasenha1">
              <i class="lock circle icon"></i>
            </div>
          </div>
          <div class="field">
            <label>Confirmação de Senha</label>
            <div class="ui left icon input">
              <input type="password" placeholder="Confirmação de Senha" name="novasenha2">
              <i class="lock circle icon"></i>
            </div>
          </div>
          <a href="login.php">
          <button class="ui button espacobotao green" type="button">Enviar</button>
          </a>
        </div>
  </div>
  </div>
  </div>
  </div>
	</div>