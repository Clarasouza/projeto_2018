<?php
include'cabecalho.php';
?>
<center>
	<h1>As suas imagens não correspondem ao formato correto</h1>
	<h2>Selecione as imagens corretamente</h2>
</center>