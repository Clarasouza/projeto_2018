<?php

    //Verificar se a página ja foi curtida
    $verifica_curtidas = file_get_contents("curtidas.json");
    $lista_curtidas = json_decode($verifica_curtidas,true);

    $esta_curtida = false;

    foreach ($lista_curtidas as $like){

        if ($like['usuario'] == 1 AND $like['resenha'] == 1 AND $like['curtiu'] == true){

            $esta_curtida = true;

        }

    }

    if (isset ($_GET['acao']) AND $_GET['acao'] == "curtir"){

        $curtidas = array();

        $curtida = [
            "resenha" => 1,
            "usuario" => 1,
            "curtiu"  => true
        ];

        $curtidas[] = $curtida;

        $curtidas_json = json_encode($curtidas, JSON_PRETTY_PRINT);

        file_put_contents('curtidas.json', $curtidas_json);

    }

?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1> nome do jogo </h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam consequatur culpa doloribus, dolorum est hic, illo molestiae placeat provident quas, quos repellendus soluta sunt veritatis voluptates! Cumque doloribus et totam.</p>

<?php if($esta_curtida != true) { ?>

    <a href="?acao=curtir"> curtir </a>

<?php } else { ?>

    <a href="?acao=remover"> remover curtir </a>

<?php } ?>


</body>
</html>