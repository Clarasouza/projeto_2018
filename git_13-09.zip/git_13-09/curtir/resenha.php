<?php

    $esta_curtida = false;

    $json = file_get_contents('curtidas.json');
    $lista_curtidas = json_encode($json, true);

    //algoritmo para curtir
    if (isset($_GET['acao']) AND $_GET['acao'] == 'curtir'){

        $curtida = [
                "resenha" => "xadrez_01",
                "usuario" => 1,
                "curtiu" => true

        ] ;

        $lista_curtidas
    }

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <h1>Xadrez</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A alias aspernatur consectetur cum deleniti distinctio eos modi, nostrum sed, sequi sint suscipit, temporibus. Aperiam, beatae deleniti eos nesciunt placeat provident.</p>

    <a href="#"> curtir</a>

</body>
</html>