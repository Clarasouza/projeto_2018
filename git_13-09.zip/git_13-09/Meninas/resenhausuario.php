<?php
include 'cabecalho.php';
?>
<div class="clear">.</div>
<div class="ui five column centered grid">
	<div class="column">
<img class="ui avatar image medium" src="imagens/aline.jpg">
	</div>
</div>
<section class="lateralUsuario">.</section>
<section class="conteudo">
<div class="ui secondary pointing menu">
<a  class='item'></a>
<a  class='item'></a>
<a  class='item'></a>
  <a class="item" href="favoritos.php">
    Favoritos
  </a>
  <a class="item" href="usuarioInformacoes.php">
    Informações
  </a>
  <a class="item" href="resenhausuario.php">
  	Minhas Resenhas
  </a>
</div>
</section>
<section class="lateralUsuario"></section>
<section class="lateralMR">.</section>
<section class="enviadas">
  <div class="ui card">
  <div class="image">
    <img src="/images/avatar2/large/kristy.png">
  </div>
  <div class="content">
    <a class="header">Kristy</a>
    <div class="meta">
      <span class="date">Joined in 2013</span>
    </div>
    <div class="description">
      Kristy is an art director living in New York.
    </div>
  </div>
  <div class="extra content">
    <a>
      <i class="user icon"></i>
      22 Friends
    </a>
  </div>
</div>
</section>
<section class="lateralMR">.</section>