<?php
echo "<pre>";
print_r($_FILES);
$foto1=( $_FILES['um']['type']);
echo"\n";
$foto2=($_FILES['dois']['type']);
echo "\n";
if ($foto1=='image/jpeg' or $foto1=="image/jpg" ) {
	$deu=0;
}elseif($foto1=='image/png'){
	$deu=0;
}else{
	$deu=1;
}
if ($foto2=='image/jpeg' or $foto2=="image/jpg" ) {
	$deu2=0;
}elseif($foto2=='image/png'){
	$deu2=0;
}else{
	$deu2=1;
}
if($deu + $deu2 ==0){
	echo "deu simmmmm";
}else{
	echo "deu naoooo";
}