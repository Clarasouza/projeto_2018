<?php
include 'cabecalho.php';
?>
<div class="clear">.</div>
<div class="ui five column centered grid">
	<div class="column">
<img class="ui avatar image medium" src="imagens/usua.png">
	</div>
</div>
<div class="nomeUsuario">
<h2 class="black"><?php echo $_SESSION["nome"];?></h2>
<br>
</div>
<section></section>
<section class="lateralUsuario">.</section>
<section class="conteudo">
<div class="ui secondary pointing menu">
<a  class='item'></a>
<a  class='item'></a>
<a  class='item'></a>
  <a class="item" href="favoritos.php">
    Favoritos
  </a>
  <a class="item" href="usuarioInformacoes.php">
    Informações
  </a>
  <a class="item" href="resenhausuario.php">
  	Minhas Resenhas
  </a>
</div>
</section>
<section class="lateralUsuario"></section>