<?php 
include("cabecalho.php");
include 'slider2.php';
?>
<h1 class="centra black">JOGOS</h1>
<div class="ui grid center aligned page grid ">
  <?php
  $lista=listaResenhas();
	$ver=rand(16,16);
	$curtidas=rand(2,8);
  foreach ($lista a $dados) {
    if ($dados['cod']<=$ver) {
      echo('

      <scrpit>

      function curtir($curtidas){
      	$curtidas++;
      	return $curtidas;
      }


      </script>
      <div class="four wide column ">
      <div class="ui special cards">
      <div class="ui card">
      <div class="blurring dimmable image">
      <div class="ui dimmer">
        <div class="content">
          <div class="center">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
            <div class="ui inverted button">Visualizar</div>
      </a>
          </div>
          <br>
       <div class="ui button"><div class="ui heart rating" data-max-rating="1" onclick="curtir()">'.$curtidas.'</div></div>
        </div>
      </div>
      <div class="ui image">
      <img src="imagens/'.$dados['imagem1'].'" class="visible content">
      </div>
      </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>
      </div>
      </div>
      </div>
      '); 
    }
  }
  ?>
 
</div> 
</div>
 adkawodkao
<?php
include "rodape.php";
?>


