<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/farcry3.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">Far Cry 3 </font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">
              O primeiro game da franquia revolucionou os FPS por apresentar um cenário colorido e belíssimo, além de equilibrar a linearidade exigida pelo gênero com ações fora do roteiro principal. Com isso, você deveria completar uma determinada missão, mas nada que impedisse o jogador de sair pela ilha atrás de armas e itens antes do objetivo. Outro ponto inovador era a variedade de veículos que o jogador poderia controlar. Se carros e lanchas já não eram tão comuns emno gênero de jogos de tiro em primeira pessoa, o que dizer de jet skis e asas-delta?
              <p>Dessa forma, Far Cry abocanhou diversos prêmios e criou uma enorme expectativa diante de sua sequência. Só que, para infelicidade de todos, o título seguinte não alcançou metade do sucesso de seu antecessor. A ideia de levar a franquia para uma selva africana não colou e acabou carregando a série para o fundo do poço. O sentimento foi tão frustrante que poucos eram os jogadores que esperavam ansiosamente por Far Cry 3. Para a grande maioria, seria mais um FPS daqueles que encalha na prateleira com o tempo.</p>
              <p>Entretanto o terceiro capítulo da franquia chegou sorrateiro e rapidamente tornou-se um sucesso de críticas. Ao invés de inovações do primeiro título, a Ubisoft soube aproveitar o que há de melhor no mercado e colocou de uma forma brilhante junto com o elemento mais marcante do primeiro jogo: o paraíso tropical. Sendo assim, quem não conheceu Far Cry na época em que foi lançado, pôde sentir o mesmo que os gamers mais antigos vivenciaram em seu primeiro contato com o jogo.</p>



		        </font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8" >GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/-D2dZhoPtY8" />
<iframe width="560" height="315" src="https://www.youtube.com/embed/-D2dZhoPtY8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include 'rodape.php';?>
</html>



