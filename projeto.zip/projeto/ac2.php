<html>
<head>
	<title>Detalhes dos jogos</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include'cabecalho.php'; ?>
<body>
	<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/ac2.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">Assassin's Creed 2</font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">Na mitologia do Egito antigo, o Duat (ou Tuat) é o mundo dos mortos, onde as almas vão para serem julgadas pelo que fizeram em vida. Quase toda religião busca algum sentido para o que há depois da morte, mas aqui uma característica chama a atenção: os egípcios acreditavam que Rá, o deus do Sol, passava pelo céu de leste à oeste e, à noite, cruzava o Duat na direção contrária, emergindo no dia seguinte.</p><p>Com uma nova aventura baseada justamente no Egito antigo e suas mitologias, Assassin's Creed: Origins representa, de certa forma, este exato “renascimento” para uma série de jogos que retorna após uma longa passagem por um purgatório particular.Quase toda religião busca algum sentido para o que há depois da morte, mas aqui uma característica chama a atenção: os egípcios acreditavam que Rá, o deus do Sol, passava pelo céu de leste à oeste e, à noite, cruzava o Duat na direção contrária, emergindo no dia seguinte.</p><p>O Assassin’s Creed que nasce deste período de reflexão é renovado, familiar em diversos aspectos, completamente diferente em outros. Mas, acima de tudo, é um jogo mais focado nas coisas que o tornaram grande: cenários deslumbrantes, ótimas mecânicas e uma história marcante, protagonizada por heróis tão decisivos quanto os nomes históricos que os rodeiam.</p><br><p>A origem de tudo</p><br><p>É uma simplicidade que serve primariamente a trama de Origins. Como o próprio nome diz, o jogo se propõe a contar os primeiros momentos da irmandade dos Assassinos, o grupo secreto do qual fazem (ou fizeram) parte todos os protagonistas da série até hoje. É uma narrativa que se confunde com a história do herói da vez, Bayek de Siuá, o último dos medjai, uma espécie de força policial do Egito antigo.</p><p>Para quem estava acostumado com os conteúdos inúteis e os mapas inchados de pontinhos dos últimos anos, Assassin's Creed: Origins é libertador em sua simplicidade. O mundo continua grande - talvez, seja o maior de todos falando puramente de escala -, mas a maneira como o jogo te conduz por este cenário aposta na simplicidade para realçar suas demais qualidades.</p></font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8">GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/watch?v=9PhI79WHxMw" />
		<iframe width="560" height="315" src="https://www.youtube.com/embed/Xqi2njkBzec" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>	
		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include'rodape.php'; ?>
</html>