<?php
 include 'cabecalho.php';
?>
<div class="borda_cadastro2">.</div>
<section class="cadastro">
  <br>
  <h2>Cadastro de Resenha</h2>
  <br>
  <form class="ui form">
    <div class="field">
      <p>Nome da Resenha</p>
      <input type="text" name="first-name" placeholder="Nome da Resenha">
    </div>
    <div class="field">
      <p>Resenha</p>
      <textarea placeholder="Resenha"></textarea>
    </div>
    <div class="field">
      <p>Notas do Autor</p>
      <textarea rows="2" placeholder="Nota do autor"></textarea>
    </div>
    <br>
    <br>
    <button class="ui button">Foto Resenha</button>
    <button class="ui right floated button" type="submit">Enviar</button>
  </form>
</section>
<div class="clear"></div>
<?php 
	include 'rodape.php'
?>