<html>
<head>
	<title>Detalhes dos jogos</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include'cabecalho.php'; ?>
<body>
	<script src="semantic/semantic.min.js"></script>
  <section class="texto">	
    <div class="ui items">
      <div class="item">
        <a class="ui medium image">
          <img class="ui medium  image" src="img/godofwar.jpg"> 
        </a>
        <div class="content"> 
          <section class="espaco_text">         
            <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">God of War</font></h2><br> </a>
            <div class="description">            
              <p><font color=#B8B8B8 face="century gothic italic">Primeiras impressões: O novo God of War é bem diferente dos anteriores, e isso é ótimo</p><p>Porque um velho Kratos é um novo Kratos</p><p>Logo na primeira cena de God of War, Kratos, o protagonista velho conhecido dos fãs da franquia, encontra-se no meio de uma tarefa que só ele mesmo pode realizar por si próprio. Antes que você imagine coisas, não, no novo God of War não veremos o protagonista fazendo suas necessidades. Na verdade, Kratos utiliza um machado para derrubar uma grande árvore, sem contar com nenhuma ajuda para fazer isso, apesar de não estar sozinho. Ele está acompanhado de Atreus, seu filho pequeno, que apenas observa o pai fazer o trabalho físico sem poder ajudar em muita coisa.</p><p>O tronco pesado que Kratos literalmente carrega nos ombros tem uma função importante, mas que não posso descrever neste texto porque isso configuraria um grande spoiler (que acaba desvendado minutos após a cena inicial). Mas trata-se de um dos dois detalhes os quais, por solicitação da Sony, sou obrigado a não revelar sobre a experiência que tive jogando God of War na semana passada, na sede do Santa Monica Studio, em Los Angeles. O outro detalhe a ser omitido diz respeito a uma longa cena de combate entre Kratos e um personagem misterioso, que deve ser mantida às escuras porque, dada a intensidade do encontro, merece mesmo ser abordada sem conhecimento prévio.</p><p>O game que será lançado para PlayStation 4 daqui um mês, mais exatamente em 20 de abril, poderia se chamar God of War 4, mas foi batizado “God of War”, sem um número acompanhando, da mesma forma que o primeiro título da franquia (lançado para o PS2 em 2005). “O game se chama God of War meio que para sacanear um pouco o site IMDB, para obrigá-los a colocar o ano ao lado do nome do jogo”, explica brincando Cory Barlog, diretor do game e envolvido com as aventuras de Kratos desde o primeiro título. Em seguida ele esclarece: “Se você nunca jogou um game God of War, esta é a hora perfeita para se envolver. Você não vai sentir como se precisasse jogar os anteriores, porque a história se basta sozinha, ela informa sobre o que é e te conduz pela jornada. O game foi feito para ser uma rota de acesso perfeita para todo mundo.”</p><p>A verdade é que as quase três horas de jogo a que tive acesso (nem dez por cento do total da trama completa) revelam pouco ou quase nada sobre porque encontramos Kratos nessas condições – cansado e envelhecido (a longa barba grisalha impressiona), acompanhado de um filho, armado com apenas um machado Leviathan e escondido no mundo de Midgard como se estivesse exilado. Por muitas vezes, Atreus faz perguntas para as quais o pai não possui respostas. “Eu não sei!”, Kratos exclama a cada questionamento sobre o porquê de certas coisas acontecerem com eles. Kratos, por sua vez, tem a dura tarefa de preparar o filho para encarar desafios, mas a todo tempo repete que o menino “não está pronto”. O que parece é que a relação entre os dois não é exatamente tranquila. Kratos não tem paciência com a paternidade, enquanto Atreus é teimoso e não tem o hábito de respeitar o velho pai o tempo todo. Isso é importante, visto que não há como progredir em God of War sem um trabalho cooperativo constante entre o mestre, Kratos, e o aprendiz, Atreus.</p><p>Não há como progredir em God of War sem um trabalho cooperativo constante entre o mestre, Kratos, e o aprendiz, Atreus</p><p>Pelo menos na parte inicial da aventura, essa cooperação entre Kratos e Atreus se dá de modo tímido – muito porque o menino “ainda não está pronto”, Kratos pouco depende da ajuda do filho para se safar. Durante certo combate com uma criatura de grandes proporções, Atreus pode disparar flechas para distrair o inimigo (apertando o botão quadrado), dando a Kratos o tempo para encontrar a melhor maneira de revidar. Já em momentos de embates com hordas de inimigos, o garoto serve como recurso importante para desviar a atenção, mas pouco faz diferença, porque ele jamais corre o risco de morrer (pelo menos não nesse início do jogo, pelo que pareceu). Intencionalmente, a presença de Atreus jamais deixa de ser sentida, e o jogo faz questão de mostrar que ela tem utilidade real, tanto na prática como na teoria. Durante batalhas e diante de puzzles, Atreus concede alertas e dicas verbais (com a voz marcante do ator Felipe Volpato); já entre uma batalha e outra, o menino age como um tradutor literal, desvendando e entregando a Kratos informações de certa utilidade. É provável que mais tarde a presença do garoto se torne mais crucial na jogabilidade, na medida em que o enredo se desenrola e ganhar complexidade</p></font>
            </section>
          </div>
        </div>
      </div>
    </div>
  </section>  

  <div class="espaco">.</div>
  <h2> <font face="Roboto,sans-serif" color="#B8B8B8">GAMEPLAY </font></h2>
  <object class="video">
   <param name="movie" value="https://www.youtube.com/embed/6LOD-pwJY6E" />
   <iframe width="560" height="315" src="https://www.youtube.com/embed/6LOD-pwJY6E" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
   <section class="comentario">
    <div class="ui inverted comments">
      <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
      <div class="inverted comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
          <div class="inverted metadata">
            <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>  
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
          </div>
          <div class="text" >
            <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
        <div class="comments">
          <div class="comment">
            <a class="avatar">
              <i class="user icon"></i>
            </a>
            <div class="content">
              <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
              <div class="metadata">
                <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
              </div>
              <div class="text">
                <font color=#B8B8B8>Elliot you are always so right :)</font>
              </div>
              <div class="actions">
                <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
          <div class="metadata">
            <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
      <form class="form">
        <div>
          <textarea class="textareacss"></textarea>
        </div>
        <div class="ui blue labeled submit icon button">
          <i class="icon edit"></i> Add Reply
        </div>
      </form>
    </div>
  </section>
</body>
<?php include'rodape.php'; ?>
</html>