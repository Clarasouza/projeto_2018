<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<section class="borda">.</section>
<section class="borda2">.</section>
      <br>
      <br>
      <div class="ui grid stackable">
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="wd2.php">
                <img class="ui image imagem" src="img/watchdogs2.jpg">
                <div class="ui bottom attached label"><h4><center>Watch Dogs 2</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="cod.php">
                <img class="ui image imagem" src="img/callofduty.jpg">
                <div class="ui bottom attached label"><h4><center>Call of Duty: OPS</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="wow.php">
                <img class="ui image imagem" src="img/worldwarcraft.jpg">
                <div class="ui bottom attached label"><h4><center>World of Warcraft</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="ow.php">
                <img class="ui image imagem" src="img/Overwatch.jpg">
                <div class="ui bottom attached label"><h4><center>Overwatch</center></h4></div>
              </a>
            </div>
          </div>
          <section class="espaco_inicial">,,,,,,</section>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="gow.php">
                <img class="ui image imagem" src="img/godofwar.jpg">
                <div class="ui bottom attached label"><h4><center>God of War</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="cs.php">
                <img class="ui image imagem" src="img/cs.jpg">
                <div class="ui bottom attached label"><h4><center>Counter-Strike: Global Offensive</center></h4></div>
              </a>
            </div>
          </div>

        
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="rayman.php">
                <img class="ui image imagem" src="img/rayman.jpg">
                <div class="ui bottom attached label"><h4><center>Rayman Legends</center></h4>
                </div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="tlou.php">
                <img class="ui image imagem" src="img/tlou.jpg">
                <div class="ui bottom attached label"><h4><center>The Last of Us</center></h4></div>
              </a>
            </div>
          </div>
          <section class="espaco_inicial">,,,,,,</section>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="lol.php">
                <img class="ui image imagem" src="img/lol.jpg">
                <div class="ui bottom attached label"><h4><center>League of Legends</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="horizon.php">
                <img class="ui image imagem" src="img/horizon2.jpg">
                <div class="ui bottom attached label"><h4><center>Horizon Zero Dawn</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="farc3.php">
                <img class="ui image imagem" src="img/farcry3.jpg">
                <div class="ui bottom attached label"><h4><center>Far Cry 3</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="injustice.php">
                <img class="ui image imagem" src="img/injustice.jpg">
                <div class="ui bottom attached label"><h4><center>Injustice: Gods Among Us</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="ew.php">
                <img class="ui image imagem" src="img/elsword.jpg">
                <div class="ui bottom attached label"><h4><center>Elsword</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="ac2.php">
                <img class="ui image imagem" src="img/ac2.jpg">
                <div class="ui bottom attached label"><h4><center>Assassin's Creed 2</center></h4></div>
              </a>
            </div>
          </div>
          <div class="column four wide">
            <div class="ui raised segment">
              <a href="pub.php">
                <img class="ui image imagem" src="img/pub.jpg">
                <div class="ui bottom attached label"><h4><center>PUB</center></h4></div>
              </a>
            </div>
          </div>
        </div>

      <br>
      <br>
      <br>
      <br>              
</body>
<?php include 'rodape.php';?>