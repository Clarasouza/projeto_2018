<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
	<section class="borda_cadastro">.</section>
	<section class="cadastro">
	<form class="ui form">
  <div class="field">
    <label>User name</label>
    <input type="text" name="user name" placeholder="User name">
  </div>
  <div class="field">
    <label>Password</label>
    <input type="Password" name="Password" placeholder="Password">
  </div>
  <div class="field">
  </div>
  <button class="ui button" type="submit">Submit</button>
</form>
</section>
<section class="borda_cadastro">.</section>
</body>
<?php include 'rodape.php';?>