<?php include 'cabecalho.php';?>
<meta charset="utf-8">
<section class="borda_cadastro">.</section>
<section class="cadastro">
	<br>
	<br>
	<form class="ui form">
	<div class="ui form">
  <div class="two fields">
    <div class="field">
      <label>First name</label>
      <input type="text" placeholder="First Name">
    </div>
    <div class="field">
      <label>Last name</label>
      <input type="text" placeholder="Last Name">
    </div>
    <div class="field">
      <label>User name</label>
      <input type="text" placeholder="Last Name">
    </div>
  </div>
</div>
<br>
<br>
  <div class="field">
    <label>E-mail</label>
    <input type="text" name="email" placeholder="exemple@email.com">
  </div>
  <div class="field">
    <label>Password</label>
    <input type="text" name="Password" placeholder="*******">
  </div>
<br>
  <div class="field">
  </div>
  <button class="ui button" type="submit">Submit</button>
</form>
</section>
<section class="borda_cadastro">.</section>

<?php include 'rodape.php';?>