<html>
<head>
	<title>Detalhes dos jogos</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include'cabecalho.php'; ?>
<body>
	<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/elsword.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">Elsword</font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">Elsword é um jogo de ação que mistura elementos dos clássicos jogos de plataforma 2D com os de jogos de luta. Apresenta uma pegada moderna dos jogos 3D, num mundo de fantasia medieval no qual você pode controlar diferentes heróis em sua batalha contra as forças do mal.</p><p>Seu objetivo é assumir o papel de um dos jovens heróis e usar seus golpes de luta para derrotar todos os inimigos de cada fase, até ser capaz de enfrentar o chefe final de cada uma delas.</p><p>Ao jogar com um personagem, você adquire experiência para passar de nível com ele e ficar cada vez mais forte, enquanto libera novas habilidades de batalha. Além disso, ao alcançar certos níveis, você também tem a opção de completar missões especiais que permitem que você avance para novas classes e, assim, ganhe novos poderes!</p><p>Além de poder enfrentar outros jogadores no modo de jogo chamado PVP (player versus player ou “jogador contra jogador”), Elsword também se destaca por ser um jogo de aventura online graças ao seu modo Missão, no qual você enfrenta os monstros controlados pelo computador enquanto avança na história do jogo!</p><p>Se você é fã de animes, tem tudo para curtir Elsword! Este jogo com visual anime é nitidamente inspirado nos personagens dos desenhos orientais, não apenas nas artworks, mas inclusive no visual dentro do próprio jogo!</p><p>O ritmo deste jogo de aventura também segue o estilo dinâmico e cheio de ação que fez dos animes um sucesso mundial, tão apreciados também no Brasil.</p><p>Nele, você pode jogar com vários personagens carismáticos, que inclusive envelhecem à medida que você evolui e conquista novas classes, como acontece com muitos personagens famosos nas séries orientais.</p><p>E justamente por ser um jogo estilo mangá, este jogo de ação ganhará uma surpresa especial no Brasil: ele contará com um mangá nacional em versão online, escrito e desenhado pelo quadrinista Fábio Yabu, o mesmo autor de Combo Rangers e Princesas do Mar.</p></font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8">GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/FiNIDN73Rrk" />
<iframe width="560" height="315" src="https://www.youtube.com/embed/FiNIDN73Rrk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include'rodape.php'; ?>
</html>