<html>
<head>
	<title>Detalhes dos jogos</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include'cabecalho.php';?>
<body>
	<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/callofduty.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2>Call of Duty: Black OPS</h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">Call of Duty: Black Ops é um importante título não só para a série e a famosa marca, mas também para sua produtora, a Treyarch. Este é o primeiro Call of Duty desenvolvido por ela que não se passa durante a Segunda Guerra Mundial, e sim em um período histórico mais recente. Só este ponto já é uma boa novidade para os fãs que estavam cansados do cenário anterior.</p><p>A história do game se passa na década de 60, durante a Guerra Fria. O jogador controla uma série de personagens ao longo da aventura, mas a maior parte do tempo ele entra na pele de Alex Mason, membro de uma equipe de operações especiais, que encara suas perigosas missões em locais como Vietnã, Cuba e Rússia. </p><p>Vale destacar a história por conta de seu alto teor informativo. O jogo se preocupa em situar quem está acompanhando, mostrando até mesmo personagens que replicam figuras históricas, como o então Presidente norte-americano John F. Kennedy e Fidel Castro. </p><p>A história prende o jogador entre as fases cheias de ação e as narrativas que são exibidas entre elas, nas famosas cenas de corte. A Treyarch resolveu fazer tudo com um alto teor cinematográfico, contando uma história com ritmo e estilo de filme. Isso é reforçado por cenas emblemáticas (algumas de tirar o fôlego) ao longo do game.</p><p>Outro ponto que colabora com o “climão de Hollywood” em Call of Duty: Black Ops é a presença de dubladores originários do cinema, com nomes que vieram de grandes filmes.Alex Mason, por exemplo, é dublado por Sam Worthington, de filmes como Avatar e Fúria de Titãs. Outros nomes no elenco são Gary Oldman (de O Cavaleiro das Trevas e Harry Potter), Ed Harris (Apollo 13) e o rapper/ator Ice Cube.</p></font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8" >GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/PjLk6tKVFB0" />
			<iframe width="560" height="315" src="https://www.youtube.com/embed/PjLk6tKVFB0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</object>
   <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include'rodape.php'; ?>
</html>