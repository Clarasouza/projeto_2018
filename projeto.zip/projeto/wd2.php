<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/watchdogs2.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2>Watch Dogs 2</h2><br> </a>
		      <div class="description">            
		        <p>Watch Dogs 2 é o novo jogo de ação em terceira pessoa da Ubisoft. Com versões para PS4, Xbox One e PC, o título conta a história de Marcus Holloway e seu grupo de hackers na luta contra o "ctOS 2.0", em São Francisco. Confira a análise completa do grandioso jogo de mundo aberto:</p>
				<p>A sequência direta de Watch Dogs é basicamente o que o primeiro jogo deveria ter sido. A começar pela narrativa. A pauta de vingança, explorada de forma rasa pelo desinteressante protagonista Aiden Pearce, foi deixada de lado para dar lugar a um moderno bando de hackers.</p>
				<p>Embora a temática também seja delicada como o tema vingança, Watch Dogs 2 é um game muito melhor por não se levar tão a sério. Logo no início, o protagonista Marcus Holloway é recrutado pelo "DedSec", cujo objetivo é desestruturar a versão 2.0 do sistema operacional central de São Francisco, instalado pela "Corporação Blume".</p>
				<p>O plano dos hackers para derrubar a rede de dados pessoais, que permite controlar toda a cidade, é executar ataques virtuais subsequentes em alvos pontuais. Para isso, Marcus deve cumprir favores a pessoas influentes e participar de desafios, a fim de elevar a popularidade do nome "DedSec" e, consequentemente, ampliar o número de seguidores.</p>
				<p>Há muitas referências a celebridades, figuras e organizações do mundo real, seja do mundo tecnológico ou não, como Donald Trump, presidente eleito dos Estados Unidos, o rapper Kanye West e o coletivo Anonymous, associado ao "hacktivismo". A versão satirizada da nossa realidade, complementada com diálogos bem construídos e toques de humor, é o que dita o ritmo da história.</p>
				<p>Os hackers coadjuvantes, assim como Marcus Holloway, esbanjam carisma, o que é um ponto bastante positivo, tendo em vista que o último game apresentou personagens mal desenvolvidos. Apesar de o protagonista falar pouco, há motivos de sobra para gostar dele e de suas ações.</p>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2>GAMEPLAY</h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/yi6ctlnFCc4" />
			<iframe width="560" height="315" src="https://www.youtube.com/embed/yi6ctlnFCc4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
		</object>
    <section class="comentario">
		<div class="ui comments">
  <h2 class="ui dividing header">Comentários</h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author">Matt</a>
      <div class="inverted metadata">
        <span class="date">Today at 5:42PM</span>
      </div>
      <div class="text">
       How artistic!
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author">Elliot Fu</a>
      <div class="metadata">
        <span class="date">Yesterday at 12:30AM</span>
      </div>
      <div class="text" >
        <p>This has been very useful for my research. Thanks as well!</p>
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author">Jenny Hess</a>
          <div class="metadata">
            <span class="date">Just now</span>
          </div>
          <div class="text">
            Elliot you are always so right :)
          </div>
          <div class="actions">
            <a class="reply">Reply</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author">Joe Henderson</a>
      <div class="metadata">
        <span class="date">5 days ago</span>
      </div>
      <div class="text">
       Dude, this is awesome. Thanks so much
      </div>
      <div class="actions">
        <a class="reply">Reply</a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include 'rodape.php';?>
</html>