<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/injustice.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">Injustice: God Among Us </font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">
              Injustice: Gods Among Us é um jogo de luta que coloca os jogadores a controlar personagens do universo da DC Comics em combate uns contra os outros. Como é um jogo da NetherRealm Studios, irá ter alguns personagem da série Mortal Kombat. Injustice desenvolve-se em combates num plano de duas dimensões, embora as personagens e os cenários de fundo serão em três dimensões. Cada combate consiste apenas numa ronda; no entanto, cada jogador tem duas barras de energia.Com o intuito de fazer Injustice mais acessível para jogadores casuais, o jogo usa um mecanismo apenas de quatro botões: leve, médio e pesado, juntamente com o botão "marca de carácter" que activa uma habilidade especifica desenhada para diferenciar cada personagem. Por exemplo, quando activado pelo Superman este tem um aumento de força temporário, enquanto que a "marca" do Batman faz aparecer um bando de morcegos robóticos.
              <p>Os combates baseiam-se em localizações, como a Batcaverna e a Fortaleza da Solidão, e contêm múltiplos níveis e objectos que permitem ao jogadores interagir. Cada arena tem os seus próprios elementos, e os personagens exploram-nos de maneira diferente dependendo da sua classe. Por exemplo, uma personagem que usa engenhocas, como o Batman, pode disparar projéteis para fazer explodir um automóvel, enquanto uma personagem que usa mais os poderes, como o Superman, pode agarrar no mesmo automóvel e usá-lo contra os oponentes. De acordo com Boon, selecionar os niveis onde se vai jogar é tão importante como a escolha da personagem.</p>

		        </font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8" >GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/fzbcSKkeqQs" />
<iframe width="560" height="315" src="https://www.youtube.com/embed/fzbcSKkeqQs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include 'rodape.php';?>
</html>



