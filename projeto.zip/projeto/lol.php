<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/lol.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">League Of Legends </font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">
              Com a diversidade de personagens, o League of Legends conta com 118 atualmente, cada um com seus próprios estilos, habilidades e histórias, cada um desses com suas particularidades, desde o modo de andar até em sua fala. Eles são divididos em 5 classes dentro do jogo. Assassino, Lutador, Mago, Suporte, Tanque e Francoatirador. Porém, os jogadores criaram outras classes para agilizar a escolha de um bom time dentro do jogo, que são eles ADC, Top, Mid, Suporte e Jungle. Existe todo o tipo de gente no jogo: Ursos que usam armaduras, um Pássaro criogênico, Espantalhos macabros, Magas sombrias, piratas, Mulheres-Aranhas e até mesmo sereias! Desse jeito, você pode escolher o personagem que se identifica e pode se especializar em seu estilo de jogo.

           <p> Itens balanceados
            Todos os itens do League of Legends são conquistado ao decorrer de cada batalha, Você ganha com base em sua funcionalidade no jogo, kills, minions e etc. Todos os itens podem ser batidos de frente com outros caso o inimigo saiba como contra-atacar. E, caso haja alguma vantagem maior ou menor entre um deles, a empresa sempre intervém, melhorando ou piorando ele.</p>

           <p> Sistema de Rank
            O jogo possui um sistema de ranks inteligentes, que decide quando você está apto para avançar por meio de pontuações internas. A cada rank que você conquista, você sobe de Tier, até alcançar uma nova. Ou seja: Você sempre terá um motivo para jogar. Destacam-se aqueles que sabem equipar com inteligência cada personagem.</p>

           <p> Dinheiro real: só pra te dar estilo.
            No jogo, as vantagens de quem usa dinheiro real no jogo são nulas. O máximo que você pode comprar serão skins, Roupas para os seus personagens. Nada de Pay-to-Win. A tentação de por dinheiro no jogo será cada vez maior no envolvimento com o jogo, já que as skins ficam cada vez melhores, algumas delas envolvendo até semelhanças com vilões e heróis de outras histórias. Um exemplo seria a Leblanc Cruel.</p>

		        </font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8" >GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/BGtROJeMPeE"  />
<iframe width="560" height="315" src="https://www.youtube.com/embed/BGtROJeMPeE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include 'rodape.php';?>
</html>



