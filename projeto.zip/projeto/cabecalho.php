<html>
<head>
	<meta charset="utf-8">
	<title>Resenha de Jogos</title>
	<script src="js/jquery.js"></script>
  <script type="text/javascript" src="js/js.js"></script>
	<link rel="stylesheet"  href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="css/inicial.css">
  <style type="text/css">
    .item{
      width: 10%;
    }
    .espaco_menu{
      width: 15%;
      color: #000000;
    }
  </style>
</head>
<body>
<script src="semantic/semantic.min.js"></script>
<nav id="header">
  <section class="logoespaco">.</section>
  <img src="img/logo.png" class="logo">
  <section class="logoespaco1">.</section>
  <section class="between">.</section>
  <div class="ui inverted menu">
    <section class="espaco_menu">.</section>
    <a class="item" href="index.php"><font style="vertical-align: inherit;">
      Home
    </font></a>
    <a class="item"><font style="vertical-align: inherit;">
      Fórum
    </font></a>
    <a class="item" href="cadastro.php"><font style="vertical-align: inherit;">
      Cadastro      
    </font></a>
    <a class="item" href="cadastro_resenha.php"><font style="vertical-align: inherit;">
      Cadastrar Resenha    
    </font></a>
    <div class="ui inverted divider"></div>
      <section class="espaco_menu">.</section>
      <div class="ui inverted transparent icon input">
      <input type="text" placeholder="Search...">
      <i class="search icon"></i>   
    </div>
    <div class="ui container">
     <a class="item" href="#"><font style="vertical-align: inherit;">
      Entrar
     </font></a>
      <div class="ui modal">
        <i class="close icon"></i>
        <div class="header">
          Nome resenha
        </div>
        <div class="pqe">
        <div class="ui medium image">
        <img src="img/pub.jpg">
        </div>
        </div>
        <div class="content">
          <textarea cols="110" rows="10">dandhawihdiawdidhawidhwiadhio</textarea>
        </div>
        <div class="actions">
          <div class="ui button green">Salvar</div>
          <div class="ui button red">Cancelar</div>
        </div>
      </div>
    </div>
      <script>
        $('.ui.modal').modal('show');
      </script>


  </div>
  </div>
</nav>
<div class="clear"></div>