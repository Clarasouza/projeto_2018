<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include 'cabecalho.php';?>
<body>
<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/tlou.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">The Last of Us</font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">Poucos jogos te seguram tanto, te fazem ter vontade de continuar a história cheia de tensão e impacto. Poucas histórias tocam seu coração a ponto de você torcer pelos personagens a cada passo, se importar com eles e se interessar pelas suas histórias, felizmente é exatamente o que a Naughty Dog fez com The Last of Us.</p><p>O game tem um grande foco em sobrevivência, com muita tensão, ação, drama e também horror. É um mundo pós-apocalíptico em que um fungo originado das formigas transformou as pessoas em infectados (não, não são zumbis mortos-vivos para sua informação), elas podem ser Runners (Corredores, na tradução) que é o estágio inicial e se algum te ver prepare-se para engajar um combate brutal e Clickers (Estaladores) um nível mais evoluído do fungo, faz com que o Infectado fique com tipo uma casca na cabeça, em consequência disso causa cegueira, porém a audição é amplificada. Com isso, podemos jogar tijolos ou garrafas em outro lugar do cenário e assim atrair a atenção do Estalador pra outro lugar e passarmos ilesos, caso contrário ele pode matar o personagem rápido e sem dar chance de se defender caso não tenha alguma arma corpo-a-corpo.</p><p>Outro aspecto interessante de se abordar é que o combate funciona extremamente bem, o jogador pode agir nas sombras e eliminar seus inimigos sorrateiramente ou pode ativar o modo dane-se e sair baleando e espancando todo mundo, seja com suas mãos ou com algum pedaço de madeira, cano, taco de baseboll ou machado que encontrar. Sem contar que quando você está agachado calculando como agir, seja com inimigos humanos ou infectados, a tensão é crescente e a sua vontade de sobreviver, mesmo sendo um jogo, também é, pois nos apegamos aos personagens.</p><p>A inteligência artificial está incrivelmente bem desenvolvida, os personagens te ajudam nas horas de aperto, avisando o que vem pelos lados e pela retaguarda, te dando munição extra quando encontram alguma, e até mesmo cuidam de inimigos por si só, tirando Ellie, que apenas os distrai por alguns momentos deixando aberta a possibilidade de acertar eles pelas costas.</p></font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8" >GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/fWPdNa72CuM" />
<iframe width="560" height="315" src="https://www.youtube.com/embed/fWPdNa72CuM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include 'rodape.php';?>
</html>



