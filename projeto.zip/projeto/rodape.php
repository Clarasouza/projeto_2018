<footer>
	<div class="ui inverted divider"></div>
	<br>
	<br>
	<section class="espaco_footer">abababababa.</section>
	<section class="footer">
	<div class="ui bulleted list">
  		<div class="item">Gaining Access</div>
  		<div class="item">Inviting Friends</div>
  		<div class="item">
    		<div>Benefits</div>
    	<div class="list">
     		<a class="item" href="#">Link to somewhere</a>
     	 	<div class="item">Rebates</div>
     		<div class="item">Discounts</div>
    	</div>
  	</div>
	  <div class="item">Warranty</div>
	</div>
	<section class="botao">
	<button class="ui circular facebook icon button">
		  <i class="facebook icon"></i>
		</button>
		<button class="ui circular twitter icon button">
		  <i class="twitter icon"></i>
		</button>
		<button class="ui circular linkedin icon button">
		  <i class="linkedin icon"></i>
		</button>
		<button class="ui circular google plus icon button">
		  <i class="google plus icon"></i>
	</button>
	</section>
	</div>
	</div>
	</section>
	<section class="espaco_footer">.</section>
</footer>
</body>
</html>