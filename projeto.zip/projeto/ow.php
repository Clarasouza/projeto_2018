<html>
<head>
	<title>Detalhes dos jogos</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="semantic/semantic.css">
	<link rel="stylesheet" type="text/css" href="inicial.css">
</head>
<?php include'cabecalho.php'; ?>
<body>
	<script src="semantic/semantic.min.js"></script>
<section class="texto">	
<div class="ui items">
		  <div class="item">
		    <a class="ui medium image">
		      <img class="ui medium  image" src="img/overwatch.jpg"> 
		    </a>
		    <div class="content"> 
        <section class="espaco_text">         
		      <a class="header"><h2><font color=#B8B8B8 face="Roboto,sans-serif">Overwatch</font></h2><br> </a>
		      <div class="description">            
		        <p><font color=#B8B8B8 face="century gothic italic">Na verdade, a história de Overwatch existe. Trata-se de um grupo de heróis especiais criados pelas Nações Unidas para combater os Omnics, robôs mortíferos que ameaçam os seres vivos. O enredo está mais claro nas animações do jogo na internet. Tudo isso pouco interessa ao ligar seu PlayStation 4, Xbox One ou PC.</p><p>Como a franquia Team Fortress, o que importa em Overwatch é seu modo multiplayer. O jogo não traz nenhum modo história. Só há um tutorial e as partidas tipo Arcade (time A contra time B) ou modalidades específicos, como o especial Paraíso Congelado de Natal com a personagem Mei. O foco é no tiroteio com personagens distintos com poderes especiais, imitando MOBAs como League of Legends.</p><p>Cada personagem tem funções específicas. Geralmente ele possui uma arma com tiro tradicional, um boost de velocidade, uma habilidade especial, e uma defesa. E ele pode ser de um dos quatro tipos: Ofensivo, Defensivo, Tanque ou Suporte.</p><p>Alguns heróis, principalmente os de suporte, não seguem a regra de uma arma, velocidade e habilidade espcial. Para entender cada personagem, é bom verificar seus comandos antes de escolher.</p><p>Personagens ofensivos foram compostos para ataque. A meta é causar o maior número de dano e mortes no time adversário, seja usando rifles, pistolas ou mesmo espadas. Genji, McCree, Pharah, Reaper, Soldado 76, Sombra e Tracer pertencem a esta classe.</p></font>
            </section>
		      </div>
		    </div>
		  </div>
		</div>
</section>  

		<div class="espaco">.</div>
    <h2> <font face="Roboto,sans-serif" color="#B8B8B8">GAMEPLAY </font></h2>
		<object class="video">
			<param name="movie" value="https://www.youtube.com/embed/wqJio94lGg4" />
      <iframe width="560" height="315" src="https://www.youtube.com/embed/wqJio94lGg4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>		</object>
    <section class="comentario">
		<div class="ui inverted comments">
  <h2 class="ui inverted dividing header"> <font face="Roboto,sans-serif">Comentários</font></h2>
  <div class="inverted comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Matt</font></a>
      <div class="inverted metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">Today at 5:42PM</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">How artistic!</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
		<i class="user icon"></i>  
	</a>
    <div class="content">
      <a class="author" ><font color=#B8B8B8 face="century gothic italic">Elliot Fu</font></a>
      <div class="metadata">
        <span class="date" ><font color=#B8B8B8 face="century gothic italic">Yesterday at 12:30AM</font></span>
      </div>
      <div class="text" >
        <p><font color=#B8B8B8 face="century gothic italic">This has been very useful for my research. Thanks as well!</font></p>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <i class="user icon"></i>
        </a>
        <div class="content">
          <a class="author" ><font color=#B8B8B8 face="century gothic italic">Jenny Hess</font></a>
          <div class="metadata">
            <span class="date" ><font color=#B8B8B8 face="century gothic italic">Just now</font></span>
          </div>
          <div class="text">
            <font color=#B8B8B8>Elliot you are always so right :)</font>
          </div>
          <div class="actions">
            <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <i class="user icon"></i>
    </a>
    <div class="content">
      <a class="author"><font color=#B8B8B8 face="century gothic italic">Joe Henderson</font></a>
      <div class="metadata">
        <span class="date"><font color=#B8B8B8 face="century gothic italic">5 days ago</font></span>
      </div>
      <div class="text">
        <font color=#B8B8B8 face="century gothic italic">Dude, this is awesome. Thanks so much</font>
      </div>
      <div class="actions">
        <a class="reply"><font color=#B8B8B8 face="century gothic italic">Reply</font></a>
      </div>
    </div>
  </div>
  <form class="form">
    <div>
      <textarea class="textareacss"></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Add Reply
    </div>
  </form>
</div>
</section>
</body>
<?php include'rodape.php'; ?>
</html>